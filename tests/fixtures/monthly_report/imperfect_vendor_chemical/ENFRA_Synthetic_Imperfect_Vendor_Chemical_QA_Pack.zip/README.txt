ENFRA - SYNTHETIC IMPERFECT DOCUMENT PACK
========================================
All people, sites, companies and measurements are invented. None of these
files are real vendors, actual chemical sampling results or client evidence.

Each editable DOCX also has a native-text PDF companion converted with
LibreOffice. The DOCX may expose document items differently from PDF pages,
so expected PDF page numbers are a visual oracle, not necessarily the DOCX
source-item numbering used by the importer.

VENDOR SERVICE MIXED PAGES - Demo North
  page 1: real technical content (inspect; no replacement claimed)
  page 2: entirely blank page
  page 3: legal-only terms
  page 4: signature-only
  page 5: price-bearing quotation; work not performed

WATER TREATMENT MIXED PAGES - Demo North
  page 1: chemical measurements; chlorides over range, culture pending
  page 2: chart and technical recommendation that should be retained
  page 3: legal-only boilerplate
  page 4: signature-only
  page 5: blank

VENDOR AMBIGUOUS DATE - Demo North
  page 1: planned inspection; completion field says Invalid date
  page 2: future follow-up; not a completed repair

CHEMICAL DIFFERENT SITE - Demo South
  page 1: measurements and sampled asset for another site
  page 2: price-bearing chemical order; unapproved
  page 3: blank

WATER TREATMENT IMAGE-ONLY SCAN - Demo North (PDF ONLY)
  page 1: visual technical data, no PDF text layer: must require review
  page 2: entirely blank

TEST EXPECTATIONS
* Place vendor work findings under Monthly Activity Summary, not onsite calls.
* Place water-treatment readings and relevant page images under Water Treatment.
* Never include pricing, legal-only, blank or signature-only pages in output.
* Never infer that a pending culture is negative or a scheduled repair complete.
* Never reuse Demo South data in a Demo North report.
* Never silently drop the real chart because another page was disallowed.
* Track original hashes, decisions and page-to-section lineage.
* Exclusions and deliberate removals must persist across refresh and replay.
* Synthetic tests are not proof of authentic-client Word/PDF parity.

Use MANIFEST.json to check exact hashes and page scenarios.
